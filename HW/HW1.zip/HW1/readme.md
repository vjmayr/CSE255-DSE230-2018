This folder contains all material needed to complete Homework 1.

The submission deadline is 11:59 Pacific Time on April 12th, 2018
